/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, setTickInterval, Player, Lang } from "./Minecraft.js";
import "./list.js";
Server.on('ready', data => {
    Server.broadcast(`${Lang.MSC} §5§lROT has been imported in ${data.loadTime} ticks.`);
});
setTickInterval(function() {
    for(let i = 0;i < Player.list().length;i++) {
        var tags = Player.getTags(Player.list()[i]);
        for(let i2 = 0;i2 < tags.length;i2++) {
            if(tags[i2].startsWith('ROT ')) {
                var command = tags[i2].replace('ROT ','').split(' ')[0]
                var args = tags[i2].replace(`ROT ${command} `,'').split(' ');
                var command_reg = Server.command.getRegistration(command.split('.')[0]);
                if(command_reg) {
                    // @ts-ignore
                    command_reg.callback({"sender":{"nameTag":Player.list()[i],"name":Player.list()[i],"location":{"x":command.split('.').length > 1 ? command.split('.')[1].split('-')[0] : "0","y":command.split('.').length > 1 ? command.split('.')[1].split('-')[1] : "0","z":command.split('.').length > 1 ? command.split('.')[1].split('-')[2] : "0"}}},args);
                }
            }
        }
    }
},20);
