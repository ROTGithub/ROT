/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname: string = `feed`
const registerInformation = {
    cancelMessage: true,
    name: `${CMDTname}`,
    description: `When you type ${Server.CP}${CMDTname} in chat, I'll feed you.`,
    usage: `${CMDTname}`,
    example: [
        `${CMDTname}`
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!Server.player.findTag('rot', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if(!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if(Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if(!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if(Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticmdpvp}"}]}`])
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.feedFB}"}]}`,`effect @a[name="${chatmsg.sender.nameTag}"] saturation 2 255 true`]) 
});