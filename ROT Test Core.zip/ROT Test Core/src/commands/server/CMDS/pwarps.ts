/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname: string = `pwarp`;
const registerInformation = {
    cancelMessage: true,
    name: 'pwarp',
    description: 'Use this command to list, set, warp to, or remove your personal warps',
    usage: '<list | set | remove | warp> [pwarp name]',
    example: [
        'pwarp list',
        'pwarp set <pwarp name>',
        'pwarp remove <pwarp name>',
        'pwarp warp <warp name>'
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!Server.player.findTag('rot', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if(!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if(Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if(!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 })) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if(Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticmdpvp}"}]}`])
    const data = Server.runCommand(`tag "${chatmsg.sender.nameTag}" list`);
    const coordFormat = /(?<=[x-zX-Z]: )(-\d+|\d+)/g;
    const pwarpName = args.slice(1).join(' ').toLowerCase();
    const pwarpRegex = new RegExp(`\\$\\(ROT{pwarp-Name: ${pwarpName}, X: (-\\d+|\\d+), Y: (-\\d+|\\d+), Z: (-\\d+|\\d+)(.*)}\\)`);
    const findpwarpNames = /(?<=\$\(ROT{pwarp-Name: ).+?(?=, X: (-\d+|\d+), Y: (-\d+|\d+), Z: (-\d+|\d+)}\))/g;
    const findXYZ = `${data.statusMessage.match(pwarpRegex)}`.match(coordFormat);
    let listOptions = ['list', 'all'];let setOptions = ['set', 'add'];let removeOptions = ['remove', 'unadd'];let warpOptions = ['warp', 'tp'];
    if(!args.length || listOptions.includes(args[0])) {
        const allpwarps = data.statusMessage.match(findpwarpNames);
        return Server.broadcast(`${allpwarps ? `${Lang.MSC} §bYou have total of §e${allpwarps.length} §bwarps.\nHere are the list of your personal warps: \n§a${allpwarps.join('§r,\n §a')}` : `${Lang.MSC} §cIt seems like you haven\'t set any warps, yet-`}`, chatmsg.sender.nameTag), Server.runCommand(`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`);
    } else if(setOptions.includes(args[0])) {
        if(!args[1]) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cPlease type a UNIQUE warp name to set!"}]}`]);
        if(pwarpName.match(coordFormat)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cYou may not indentify your warp name in a coordinate format!"}]}`]);
        if(data.statusMessage.match(pwarpRegex)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cYou already have a warp set with that name!"}]}`]);
        Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`tag "${chatmsg.sender.nameTag}" add "$(ROT{pwarp-Name: ${pwarpName}, X: ${Math.trunc(chatmsg.sender.location.x)}, Y: ${Math.trunc(chatmsg.sender.location.y)}, Z: ${Math.trunc(chatmsg.sender.location.z)}})"`]);
        return Server.broadcast(`${Lang.MSC} §bYou have set a warp with the name §a${pwarpName} §bat§r: §a${Math.trunc(chatmsg.sender.location.x)}§r, §a${Math.trunc(chatmsg.sender.location.y)}§r, §a${Math.trunc(chatmsg.sender.location.z)}`, chatmsg.sender.nameTag);
    } else if(removeOptions.includes(args[0])) {
        if(!args[1]) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cPlease type a warp name to remove!"}]}`]);
        if(!data.statusMessage.match(pwarpRegex)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cYou don't have a warp with that name!"}]}`]);
        else {
            Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`tag "${chatmsg.sender.nameTag}" remove "$(ROT{pwarp-Name: ${pwarpName}, X: ${findXYZ[0]}, Y: ${findXYZ[1]}, Z: ${findXYZ[2]}})"`]);
            return Server.broadcast(`${Lang.MSC} §bSuccessfully removed warp with the name §a${pwarpName} §bat §a${findXYZ[0]}§r, §a${findXYZ[1]}§r, §a${findXYZ[2]}`, chatmsg.sender.nameTag);
        };
    } else if(warpOptions.includes(args[0])) {
        if(!args[1]) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cPlease type a warp name to warp to!"}]}`]);
        if(!data.statusMessage.match(pwarpRegex)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cYou don't have a warp with that name!"}]}`]);
        Server.runCommand(`execute "${chatmsg.sender.nameTag}" ~~~ tp @s ${findXYZ[0]} ${findXYZ[1]} ${findXYZ[2]}`);
        return Server.broadcast(`${Lang.MSC} §bYou have been teleported to §a${findXYZ[0]}§r, §a${findXYZ[1]}§r, §a${findXYZ[2]}`, chatmsg.sender.nameTag);
    } else return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error2}"}]}`]);
});