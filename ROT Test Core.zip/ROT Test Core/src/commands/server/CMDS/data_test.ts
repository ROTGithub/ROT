/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Database } from '../../../Minecraft.js';
const registerInformation = {
    cancelMessage: true,
    name: 'dataset',
    description: 'Data Storage Test',
    usage: 'dataset <Key: String> <Value: String>',
    example: [
        'datatest key value'
    ]
};
var userdb = new Database("ROT_user_db_test");
Server.command.register(registerInformation, (chatmsg, args) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
  try {
    var VAL = "";
    for(let i = 1;i < args.length;i++) {
      VAL += args[i] + " ";
    }
    userdb.set(args[0],VAL);
  } catch(e) {

  }
});
Server.command.register({
    cancelMessage: true,
    name: 'datadel',
    description: 'Data Storage Test',
    usage: '<Key: String>',
    example: [
        'datatest key'
    ]
}, (chatmsg,args) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
  if(userdb.has(args[0])) userdb.delete(args[0])
})

Server.command.register({
    cancelMessage: true,
    name: 'dataread',
    description: 'Data Storage Test',
    usage: '<Key: String>',
    example: [
        'datatest key'
    ]
}, (chatmsg,args) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
  if(userdb.has(args[0])) {
    var val = userdb.get(args[0])
    Server.broadcast("Value: "+val,chatmsg.sender.nameTag)
  }
})