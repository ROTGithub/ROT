/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const registerInformation = {
    cancelMessage: true,
    name: 'vanish',
    description: 'Makes you vanish out of thin air so you can spy on people!',
    usage: 'vanish',
    example: [
        'v',
        'vanish'
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!Server.player.findTag('rot', chatmsg.sender.nameTag)) return Server.runCommands([ `playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if(!Server.player.findTag('v', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if(!Server.player.findTag('vanish', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`tag @a[name="${chatmsg.sender.nameTag}"] remove unvanish`,`tag @a[name="${chatmsg.sender.nameTag}"] add vanish`,`effect @a[name="${chatmsg.sender.nameTag}"] invisibility 100000 255 true`,`effect @a[name="${chatmsg.sender.nameTag}"] night_vision 100000 255 true`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.v1}"}]}`,`event entity @a[name="${chatmsg.sender.nameTag}"] rot:vanish`]);
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`event entity @a[name="${chatmsg.sender.nameTag}"] rot:unvanish`,`tag @a[name="${chatmsg.sender.nameTag}"] add dvvanish`,`effect @a[name="${chatmsg.sender.nameTag}"] invisibility 0`,`effect @a[name="${chatmsg.sender.nameTag}"] night_vision 0`,`tag @a[name="${chatmsg.sender.nameTag}"] remove vanish`,`tag @a[name="${chatmsg.sender.nameTag}"] add unvanish`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.v2}"}]}`,`tag @a[name="${chatmsg.sender.nameTag}"] remove dvvanish`
    ]);
});