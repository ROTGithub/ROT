/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Database, Lang } from '../../../Minecraft.js';
var players = new Database("players")
var muted_players = new Database("muted_players");
var CONFIG = new Database("rot_config");
if(!CONFIG.has('joinmsg')) CONFIG.set('joinmsg','undefined');
// @ts-ignore
function removeValue(arr,val) {
    for( var i = 0; i < arr.length; i++){ 
    if ( arr[i] === val) { 
        arr.splice(i, 1); 
    }
}};
Server.addListener("playerJoin", player => {
    if(players.has("members")) {
        var members = players.get("members").split('/n//');
        if(members.includes(player.nameTag)) {
            return;
        } else {
            var server_id = (Math.floor(Math.random() * 10000000)).toString();
            players.set(`server_id_${player.nameTag}`,server_id);
            players.set("members",`${players.get("members")}/n//${player.nameTag}`)
            if(CONFIG.get('joinmsg') !== "undefined") Server.broadcast(CONFIG.get('joinmsg'),player.nameTag);
        }
    } else {
        players.set(`server_id_${player.nameTag}`,(Math.floor(Math.random() * 10000000)).toString());
        players.set("members",`${player.nameTag}`)
    }
});
Server.command.register({
    cancelMessage: true,
    name: `members`,
    usage: `members`,
    description: `Shows people who have joined before`
},(data)=> {
    if (!Server.player.findTag('rot', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    var members = players.get("members").split('/n//');
    Server.runCommands([`playsound random.toast @a[name="${data.sender.nameTag}"] ~~~ 1 0.5`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC}"}]}`]);
    for(let i = 0;i < members.length;i++) {
        Server.broadcast(`§c(§dID: §a${players.get("server_id_"+members[i])} §dName: §a${members[i]}§c)`,`${data.sender.nameTag}`);
    };
});
Server.command.register({
    cancelMessage: true,
    name: `mute`,
    usage: `mute <Name>`,
    description: `Mute a player`
},(data,args)=> {
    if (!Server.player.findTag('rot', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if(!Server.player.find(args.join(' '))) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0065\u0055\u006e\u0061\u0062\u006c\u0065 \u0074\u006f \u0066\u0069\u006e\u0064 \u0070\u006c\u0061\u0079\u0065\u0072\u003a ${args.join(' ')}"}]}`]);
    if(muted_players.has('mute')) {
        muted_players.set('mute',`${muted_players.get('mute')}/n//${args.join(' ')}`);
        return Server.runCommands([`playsound random.toast @a[name="${data.sender.nameTag}"] ~~~ 1 0.5`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} "}]}`]);
    }
});
Server.command.register({
    cancelMessage: true,
    name: `unmute`,
    usage: `unmute <Name>`,
    description: `Unmute a player`
},(data,args)=> {
    if (!Server.player.findTag('rot', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if(muted_players.has('mute')) {
        var muted_players_list = muted_players.get('mute').split('/n//');
        if(muted_players_list.includes(`${args[0]}`)) {
            removeValue(muted_players_list,args.join(' '));
            muted_players.set('mute',muted_players_list.join('/n//'));
            return Server.broadcast("§a§lSuccess: muted player has been unmuted",data.sender.nameTag);
        } else {
            return Server.broadcast("§c§lError: muted player not found (Error Code: 000)",data.sender.nameTag);
        }
    } else {
        return Server.broadcast("§c§lError: there are no muted players (Error Code: 001)",data.sender.nameTag);
    }
});
Server.command.register({
    cancelMessage: true,
    name: `get-muted-players`,
    usage: `get-muted-players`,
    description: `See all muted players`
},(data)=> {
    if (!Server.player.findTag('rot', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', data.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if(muted_players.has('mute')) {
        var muted_players_list = muted_players.get('mute').split('/n//');
        Server.runCommands([`playsound random.toast @a[name="${data.sender.nameTag}"] ~~~ 1 0.5`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC}"}]}`]);
        for(let i = 0;i < muted_players_list.length;i++) {
            Server.broadcast(`§c(§dMuted Players§c) §b${muted_players_list[i]}`,`${data.sender.nameTag}`);
        }
    } else {
        return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`,`tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} "}]}`]);
    };
});