/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang, } from '../../Minecraft.js';
const CMDTname = "close"
const registerInformation = {
    private: true,
    cancelMessage: true,
    name: `${CMDTname}`,
    description: `When you type ${Server.CP}${CMDTname} in chat, time will end!`,
    usage: `${CMDTname} [command]`,
    example: [
        `${CMDTname}`
    ]
};
var RotDevelopers = ["moisesgamingtv9","SamoyedDiamond5","BasementDump","PowerTrash5771","DogLog20","turdnugget77469","fireshardpk"]
Server.command.register(registerInformation, (chatmsg) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!RotDevelopers.includes(chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":""${Lang.MSC} \u00a7\u0034\u0059\u006f\u0075 \u0061\u0072\u0065 \u006e\u006f\u0074 \u0061 \u0064\u0065\u0076\u0065\u006c\u006f\u0070\u0065\u0072 \u006f\u0066 \u0052\u004f\u0054\u0021}]}`]);
    Server.close();
});