/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang, Database, MS } from "../../../Minecraft.js";
export const db = new Database('ROT_bannedPlayers');
const findPlayerRegex = /(?<=^')([^']+)(?=')/;
const timeFormatRegex = /^\d+\.?\d*\s?((years*?|yrs*?)|(weeks*?)|(days*?)|(hours*?|hrs*?)|(minutes*?|mins*?)|(seconds*?|secs*?)|(milliseconds*?|msecs*?|ms)|[smhdwy])(?!\S)(?=\s?)/;
const registerInformation = {
    private: true,
    cancelMessage: true,
    name: 'scban',
    description: 'Simple ban command...',
    usage: '"<player>" [ban length] [reason]',
    example: [
        'ban "notbeer" 30 minutes Using foul language',
        'ban "notbeer" 10 hours Bullying player',
        'ban "notbeer" 1 day Spamming chat',
        'ban "notbeer" 4 weeks Hacking'
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!args.join(' ').match(findPlayerRegex)) return Server.broadcast(`${Lang.MSC} §cType the player name in quotations for the first argument`, chatmsg.sender.nameTag);
    const player = args.join(' ').match(findPlayerRegex)[0];
    const foundPlayer = Server.player.find(player);
    if(!foundPlayer) return Server.broadcast(`${Lang.MSC} §cCouldn't find player §f"§a${player}§f" §conline`, chatmsg.sender.nameTag);
    if(foundPlayer && player === chatmsg.sender.nameTag) return Server.broadcast(`${Lang.MSC} §cYou cannot ban yourself`, chatmsg.sender.nameTag);
    if(Server.player.findTag('v', player)) return Server.broadcast(`${Lang.MSC} §cYou may not ban a staff member!`, chatmsg.sender.nameTag);
    if(db.has(player)) return Server.broadcast(`${Lang.MSC} §cPlayer §f"§a${player}§f" §cis already banned...`, chatmsg.sender.nameTag);
    let restArgs = args.join(' ').match(new RegExp(`(?<=^"${player}"\\s).+`));
    if(!restArgs || !restArgs[0].match(timeFormatRegex)) return Server.broadcast(`§c${restArgs ? 'Invalid' : 'Missing'} ban length argument`, chatmsg.sender.nameTag);
    const time = MS(restArgs[0].match(timeFormatRegex)[0]);
    const reason = restArgs[0].replace(timeFormatRegex, '').replace(/^\s/, '');
    const today = new Date();
    const banData = {
        bannedPlayer: player,
        date: `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`,
        length: time,
        unbanTime: today.getTime() + time,
        reason: reason,
        bannedBy: chatmsg.sender.nameTag
    };
    db.set(player, banData);
});
Server.on('tick', () => {
    const currentTime = new Date().getTime();
    const bannedPlayers = db.getCollection();
    if(!bannedPlayers) return;
    for(let key in bannedPlayers) {
        if(bannedPlayers.hasOwnProperty(key) && bannedPlayers[key]?.bannedPlayer) {
            if(bannedPlayers[key]?.unbanTime < currentTime) db.delete(key);
            else Server.runCommand(`kick "${bannedPlayers[key]?.bannedPlayer}" §r\n§cYou have been banned for §a${MS(bannedPlayers[key]?.length)}§c from this server at §b${bannedPlayers[key]?.date}${bannedPlayers[key]?.reason ? `\n§7Reason: §r${bannedPlayers[key]?.reason}`: ''}`);
        };
    };
});