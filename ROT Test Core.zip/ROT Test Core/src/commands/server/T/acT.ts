/*
ROT Developers and Contributors:
Moises (OWNER/CEO), 
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |   
 |    |   \/    |    \    |   
 |____|_  /\_______  /____|   
        \/         \/         
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname: string = 'ac';
const registerInformation = {
    cancelMessage: true,
    name: `${CMDTname}`,
    description: `Turns the UAC anti cheat off, and on.`,
    usage: `${CMDTname}`,
    example: [
        `${CMDTname}`
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if(!Server.player.find(chatmsg.sender.nameTag)) return null;
    if(!Server.player.findTag('rot', chatmsg.sender.nameTag)) return Server.runCommands([ `playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if(!Server.player.findTag('v', chatmsg.sender.nameTag)) return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if(Server.entity.getScore(`cl${CMDTname}`,'[type=rot:cl]', { minimum: 1, maximum: 1 })) return Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`scoreboard players set @e[type=rot:cl] cl${CMDTname} 0`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"\u00a7\u0065\u0054\u0075\u0072\u006e\u0069\u006e\u0067 \u006f\u0066\u0066 \u0074\u0068\u0065 \u0055\u0041\u0043 \u0061\u006e\u0074\u0069 \u0063\u0068\u0065\u0061\u0074\u002e\u002e\u002e\n\u00a7\u0061\u0044\u006f\u006e\u0065\u0021"}]}`]);
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`,`scoreboard players set @e[type=rot:cl] cl${CMDTname} 1`,`tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"\u00a7\u0065\u0054\u0075\u0072\u006e\u0069\u006e\u0067 \u006f\u006e \u0074\u0068\u0065 \u0055\u0041\u0043 \u0061\u006e\u0074\u0069 \u0063\u0068\u0065\u0061\u0074\u002e\u002e\u002e\n\u00a7\u0061\u0044\u006f\u006e\u0065\u0021"}]}`]);
});