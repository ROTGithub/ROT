/*
This addon is made entirely by trash,
this shit is not open source,
and if you copy it...
j
fdsklfdjflksdjcklsd
fdk;ldjsklgfdsf
dwdsjgkfds;s
*/
//ban
import './commands/server/ban/unban.js';
import './commands/server/ban/ban.js';
import './commands/server/ban/SCban.js';
//CMDS
import './commands/server/CMDS/warps.js';
import './commands/server/CMDS/text.js';
import './commands/server/CMDS/wild.js';
import './commands/server/CMDS/smite.js';
import './commands/server/CMDS/killtext.js';
import './commands/server/CMDS/gui.js';
import './commands/server/CMDS/v.js';
import './commands/server/CMDS/vanish.js';
import './commands/server/CMDS/cmd.js';
import './commands/server/CMDS/member_management.js';
import './commands/server/CMDS/data_test.js';
import './commands/server/CMDS/feed.js';
import './commands/server/CMDS/fly.js';
import './commands/server/CMDS/heal.js';
import './commands/server/CMDS/home.js';
import './commands/server/CMDS/kill.js';
import './commands/server/CMDS/nothing.js';
import './commands/server/CMDS/pwarps.js';
import './commands/server/CMDS/rickroll.js';
import './commands/server/CMDS/uac.js';
import './commands/server/CMDS/notes.js';
import './commands/server/CMDS/server_broadcast.js';
import './commands/server/CMDS/server_info.js';
import './commands/server/CMDS/top.js';
//Spawn
import './commands/server/T/spawnT.js';
import './commands/server/CMDS/spawn.js';
//T
import './commands/server/T/veinT.js';
import './commands/server/T/warpsT.js';
import './commands/server/T/feedT.js';
import './commands/server/T/flyT.js';
import './commands/server/T/healT.js';
import './commands/server/T/healthT.js';
import './commands/server/T/wildT.js';
import './commands/server/T/homeT.js';
import './commands/server/T/killT.js';
import './commands/server/T/pwarpT.js';
import './commands/server/T/sleepT.js';
import './commands/server/T/topT.js';
//Server
import './commands/server/close.js';
import './commands/server/config.js';
//Main
import './commands/setup.js';
import './commands/debug.js';
import './commands/server/T/acT.js';
import './commands/help.js';
