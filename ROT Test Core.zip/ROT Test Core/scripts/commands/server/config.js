/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang, Database } from '../../Minecraft.js';
export const CONFIG = new Database("rot_config");
var CHAT_LOGGER = new Database("chatlogger");
if (!CHAT_LOGGER.has("messages"))
    CHAT_LOGGER.set('messages', '0');
if (!CHAT_LOGGER.has("pages"))
    CHAT_LOGGER.set('pages', '1');
if (!CONFIG.has('rot_id'))
    CONFIG.set('rot_id', Math.floor(Math.random() * 1525000000).toString());
if (!CONFIG.has('chatlogger'))
    CONFIG.set('chatlogger', '0');
Server.command.register({
    cancelMessage: true,
    name: `prefix`,
    usage: `prefix <Prefix>`,
    example: [
        `prefix $`,
        `prefix ?`
    ]
}, (chatmsg, args) => {
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]} `]);
    if (args[0].startsWith('/'))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0063\u0050\u006c\u0065\u0061\u0073\u0065 \u0064\u006f \u004e\u004f\u0054 \u0075\u0073\u0065 \u0061\u006e\u0079\u0074\u0068\u0069\u006e\u0067 \u0074\u0068\u0061\u0074 \u0073\u0074\u0061\u0072\u0074\u0073 \u0077\u0069\u0074\u0068 \u005c\u0022\u002f\u005c\u0022! \u0049\u0074\u0027\u006c\u006c \u0062\u0072\u0065\u0061\u006b \u0052\u004f\u0054 \u0061\u006e\u0064 \u006d\u0061\u006b\u0065 \u0069\u0074 \u0075\u006e\u0075\u0073\u0061\u0062\u006c\u0065 \u0077\u0069\u0074\u0068\u006f\u0075\u0074 \u0063\u006f\u006d\u0070\u006c\u0065\u0074\u0065\u006c\u0079 \u0064\u0065\u006c\u0065\u0074\u0069\u006e\u0067 \u0061\u006c\u006c \u0064\u0061\u0074\u0061\u0062\u0061\u0073\u0065 \u0064\u0061\u0074\u0061\u002e"}]}`]);
    if (!args[0])
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0063\u0059\u006f\u0075\u0072 \u0063\u006f\u006d\u006d\u0061\u006e\u0064 \u0070\u0072\u0065\u0066\u0069\u0078 \u0063\u0061\u006e\u006e\u006f\u0074 \u0062\u0065 \u006e\u006f\u0074\u0068\u0069\u006e\u0067\u002e"}]}`]);
    CONFIG.set('prefix', args[0]);
});
Server.command.register({
    cancelMessage: true,
    name: `chatloggert`,
    usage: `chatloggert`,
    example: [
        `chatloggert`
    ]
}, (chatmsg) => {
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]} `]);
    if (CONFIG.get('chatlogger') == '1') {
        CONFIG.set('chatlogger', '0');
    }
    else {
        CONFIG.set('chatlogger', '1');
    }
});
Server.command.register({
    cancelMessage: true,
    name: `chatlogs`,
    usage: `chatlogs <Page Number:Int>`,
    example: [
        `chatlogs 2`,
        `chatlogs 5`
    ]
}, (chatmsg, args) => {
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]} `]);
    if (CHAT_LOGGER.get('messages') == '0' && CHAT_LOGGER.get('pages') == '1')
        return;
    if (CHAT_LOGGER.has(`p${args[0]}_messages`)) {
        var MESSAGES = CHAT_LOGGER.get(`p${args[0]}_messages`).split('[///n///');
        for (let i = 0; i < MESSAGES.length; i++) {
            Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"\u00a7\u0063\u0028\u00a7\u0064\u0043\u0068\u0061\u0074 \u004c\u006f\u0067\u00a7\u0063\u0029 \u00a7\u0062${MESSAGES[i]}"}]}`]);
        }
    }
});
