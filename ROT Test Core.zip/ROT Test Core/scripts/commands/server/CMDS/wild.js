/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname = `wild`;
const registerInformation = {
    cancelMessage: true,
    name: 'wild',
    description: 'Teleports you to a random location from atleast 350 blocks away from 0, 0 and a maximum of 10,000 blocks.',
    usage: 'wild',
    example: [
        'wild'
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if (Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticlog}"}]}`]);
    Server.runCommands(['scoreboard players random @e[type=rot:cl] clwx -10000 10000', 'scoreboard players random @e[type=rot:cl] clwz -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwx=-350..350}] clwx -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwx=-350..350}] clwx -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwx=-350..350}] clwx -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwz=-350..350}] clwz -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwz=-350..350}] clwz -10000 10000', 'scoreboard players random @e[type=rot:cl,scores={clwz=-350..350}] clwz -10000 10000']);
    const wX = (Server.entity.getScore('clwx', '[type=rot:cl]'));
    const wZ = (Server.entity.getScore('clwz', '[type=rot:cl]'));
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0065\u0046\u0069\u006e\u0064\u0069\u006e\u0067 \u0061 \u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e \u0062\u0065\u0074\u0077\u0065\u0065\u006e \u0030 \u0061\u006e\u0064 \u0031\u0030\u002c\u0030\u0030\u0030\u002e\u002e\u002e \n\u004c\u006f\u0063\u0061\u0074\u0069\u006f\u006e \u0066\u006f\u0075\u006e\u0064!"}]}`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tp @s ${wX} 350 ${wZ}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clwild 1`]);
});
