/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname = `home`;
const registerInformation = {
    cancelMessage: true,
    name: 'home',
    description: 'Use this command to set, delete, or teleport to your home',
    usage: '<set | delete | tp>',
    example: [
        '',
        '§a!§rhome set',
        '§a!§rhome delete',
        '§a!§rhome tp'
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if (Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticmdpvp}"}]}`]);
    let setOptions = ['set', 'add', 'create'];
    let removeOptions = ['delete', 'remove'];
    let warpOptions = ['warp', 'tp'];
    if (setOptions.includes(args[0])) {
        let hX = Math.trunc(chatmsg.sender.location.x);
        let hY = Math.trunc(chatmsg.sender.location.y);
        let hZ = Math.trunc(chatmsg.sender.location.z);
        Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0032\u0059\u006f\u0075\u0072 \u0068\u006f\u006d\u0065 \u0068\u0061\u0073 \u0062\u0065\u0065\u006e \u0074\u006f §a${hX}§2, §a${hY}§2, §a ${hZ}§2!"}]}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clhx ${hX}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clhy ${hY}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clhz ${hZ}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clhome 1`]);
    }
    else if (removeOptions.includes(args[0])) {
        if (!Server.player.getScore('clhome', chatmsg.sender.nameTag, { maximum: 0 }))
            return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} ${Lang.nohomeFB}"}]}`]);
        Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0065\u0044\u0065\u006c\u0065\u0074\u0069\u006e\u0067 \u0068\u006f\u006d\u0065\u002e\u002e\u002e\u005c\u006e\u00a7\u0061\u0044\u006f\u006e\u0065!"}]}`, `scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clhome 0`]);
    }
    else if (warpOptions.includes(args[0])) {
        if (!Server.player.getScore('clhome', chatmsg.sender.nameTag, { maximum: 0 }))
            return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} ${Lang.nohomeFB}"}]}`]);
        let hX = Server.player.getScore(`clhx`, chatmsg.sender.nameTag);
        let hY = Server.player.getScore(`clhy`, chatmsg.sender.nameTag);
        let hZ = Server.player.getScore(`clhz`, chatmsg.sender.nameTag);
        Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0032\u0059\u006f\u0075 \u0068\u0061\u0076\u0065 \u0062\u0065\u0065\u006e \u0074\u0065\u006c\u0065\u0070\u006f\u0072\u0074\u0065\u0064 \u0074\u006f \u0079\u006f\u0075\u0072 \u0068\u006f\u006d\u0065 \u0061\u0074 §a${hX}§2, §a${hY}§2, §a${hZ}§2\u002e"}]}`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tp @s ${hX} ${hY} ${hZ}`]);
    }
    else
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error2}"}]}`]);
});
