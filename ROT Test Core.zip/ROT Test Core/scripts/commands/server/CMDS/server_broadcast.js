/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Player, Lang } from '../../../Minecraft.js';
const registerInformation = {
    cancelMessage: true,
    name: 'broadcast',
    description: 'Broadcast message to the entire server',
    usage: 'broadcast <Message>',
    example: [
        `broadcast your mom`
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.findTag('v', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    var args_joined = args.join(" ");
    args_joined = args_joined.replace(/&/g, "§");
    var players = Player.list();
    for (let i = 0; i < players.length; i++) {
        Server.runCommand(`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`);
        Server.broadcast(`${Lang.MSC} ${args_joined}`, players[i]);
    }
});
