/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname = "rickroll";
const registerInformation = {
    cancelMessage: true,
    name: `${CMDTname}`,
    description: `When you type ${Server.CP}${CMDTname} in chat, it rickrolls everybody in the server but you.`,
    usage: `${CMDTname}`,
    example: [
        `${CMDTname}`
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 8`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticmdpvp}"}]}`]);
    let r1 = `Never gonna give you up`;
    let r2 = `Never gonna let you down`;
    let r3 = `Never gonna run around and desert you`;
    let r4 = `Never gonna make you cry`;
    let r5 = `Never gonna say goodbye`;
    let r6 = `Never gonna tell a lie and hurt you`;
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0038\u0048\u0061\u0068\u0061\u002d\u0068\u0061\u0068\u0061\u002d\u0068\u0061\u0068\u0061\u002c \u0049 \u0052\u0069\u0063\u006b\u0072\u006f\u006c\u006c\u0065\u0064 \u0065\u0076\u0065\u0072\u0079\u006f\u006e\u0065 \u0069\u006e \u0074\u0068\u0065 \u0073\u0065\u0072\u0076\u0065\u0072!"}]}`]);
    Server.broadcast(`${Lang.MSC} ${r1}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
    Server.broadcast(`${Lang.MSC} ${r2}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
    Server.broadcast(`${Lang.MSC} ${r3}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
    Server.broadcast(`${Lang.MSC} ${r4}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
    Server.broadcast(`${Lang.MSC} ${r5}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
    Server.broadcast(`${Lang.MSC} ${r6}`, `@a[name=!"${chatmsg.sender.nameTag}"]`);
});
