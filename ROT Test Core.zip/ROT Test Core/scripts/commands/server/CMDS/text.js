/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang, } from '../../../Minecraft.js';
const CMDTname = "text";
const registerInformation = {
    cancelMessage: true,
    name: `${CMDTname}`,
    description: `This will make a floating text!`,
    usage: `${CMDTname} [text]`,
    example: [
        `${CMDTname} Plz donate, I'm homeless!`,
        `${CMDTname} Welcome to ROT craft or something dumb.`
    ]
};
Server.command.register(registerInformation, (chatmsg, args) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    if (!Server.player.findTag('v', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.error}"}]}`]);
    Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ summon rabbit "${args.join(' ')}" ~~~`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0061\u0043\u0072\u0065\u0061\u0074\u0069\u006e\u0067 \u0066\u006c\u006f\u0061\u0074\u0069\u006e\u0067 \u0074\u0065\u0078\u0074\u002e\u002e\u002e\n\u0043\u0072\u0065\u0061\u0074\u0065\u0064 \u0066\u006c\u006f\u0061\u0074\u0069\u006e\u0067 \u0074\u0065\u0078\u0074 \u00a7\u0063${args.join(' ')}\u00a7\u0072\u00a7\u0061!"}]}`]);
});
