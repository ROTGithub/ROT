/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#0001
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../../../Minecraft.js';
const CMDTname = `spawn`;
const registerInformation = {
    cancelMessage: true,
    name: 's',
    description: 'Teleports you to spawn.',
    usage: 'spawn',
    example: [
        'spawn',
        's'
    ]
};
Server.command.register(registerInformation, (chatmsg) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if (Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticlog}"}]}`]);
    let sptext = `${Lang.MSC} \u00a7\u0063\u0059\u006f\u0075 \u0064\u0069\u0064\u006e\u0027\u0074 \u0073\u0065\u0074\u0075\u0070 \u0079\u006f\u0075\u0072 \u0073\u0070\u0061\u0077\u006e\u0021 \u0074\u0079\u0070\u0065 \u005c\u0022\u00a7\u0037${Server.CP}\u0073\u0065\u0074\u0073\u0070\u0061\u0077\u006e\u00a7\u0063\u005c\u0022 \u0069\u006e \u0063\u0068\u0061\u0074 \u0074\u006f \u0073\u0065\u0074 \u0074\u0068\u0065 \u0061\u0072\u0065\u0061 \u0079\u006f\u0075\u0072 \u0070\u006c\u0061\u0079\u0065\u0072\u0073 \u0077\u0069\u006c\u006c \u0062\u0065 \u0074\u0065\u006c\u0065\u0070\u006f\u0072\u0074\u0065\u0064 \u0074\u006f\u002e`;
    if (Server.entity.getScore('clsx', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    if (Server.entity.getScore('clsy', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    if (Server.entity.getScore('clsz', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    const sX = Server.entity.getScore('clsx', '[type=rot:cl]');
    const sY = Server.entity.getScore('clsy', '[type=rot:cl]');
    const sZ = Server.entity.getScore('clsz', '[type=rot:cl]');
    Server.runCommands([`playsound mob.shulker.teleport @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tp @s ${sX} ${sY} ${sZ}`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0065\u0054\u0065\u006c\u0065\u006c\u0070\u006f\u0072\u0074\u0069\u006e\u0067\u002e\u002e\u002e\n\u00a7\u0061\u0050\u006f\u006f\u0066!"}]}`]);
});
Server.command.register({
    cancelMessage: true,
    name: 'spawn',
    description: 'Teleports you to spawn.',
    usage: 'spawn',
    example: [
        'spawn',
        's'
    ]
}, (chatmsg) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if (Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticlog}"}]}`]);
    let sptext = `${Lang.MSC} \u00a7\u0063\u0059\u006f\u0075 \u0064\u0069\u0064\u006e\u0027\u0074 \u0073\u0065\u0074\u0075\u0070 \u0079\u006f\u0075\u0072 \u0073\u0070\u0061\u0077\u006e\u0021 \u0074\u0079\u0070\u0065 \u005c\u0022\u00a7\u0037${Server.CP}\u0073\u0065\u0074\u0073\u0070\u0061\u0077\u006e\u00a7\u0063\u005c\u0022 \u0069\u006e \u0063\u0068\u0061\u0074 \u0074\u006f \u0073\u0065\u0074 \u0074\u0068\u0065 \u0061\u0072\u0065\u0061 \u0079\u006f\u0075\u0072 \u0070\u006c\u0061\u0079\u0065\u0072\u0073 \u0077\u0069\u006c\u006c \u0062\u0065 \u0074\u0065\u006c\u0065\u0070\u006f\u0072\u0074\u0065\u0064 \u0074\u006f\u002e`;
    if (Server.entity.getScore('clsx', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    if (Server.entity.getScore('clsy', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    if (Server.entity.getScore('clsz', '[type=rot:cl]') == undefined)
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${sptext}"}]}`]);
    const sX = Server.entity.getScore('clsx', '[type=rot:cl]');
    const sY = Server.entity.getScore('clsy', '[type=rot:cl]');
    const sZ = Server.entity.getScore('clsz', '[type=rot:cl]');
    Server.runCommands([`playsound mob.shulker.teleport @a[name="${chatmsg.sender.nameTag}"] ~~~ 1 0.5`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tp @s ${sX} ${sY} ${sZ}`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} \u00a7\u0065\u0054\u0065\u006c\u0065\u006c\u0070\u006f\u0072\u0074\u0069\u006e\u0067\u002e\u002e\u002e\n\u00a7\u0061\u0050\u006f\u006f\u0066!"}]}`]);
});
Server.command.register({
    cancelMessage: true,
    name: 'setspawn',
    description: 'Sets the world spawnpoint. This is also where people will be teleported if they type "!setspawn"',
    usage: 'setspawn',
    example: [
        'setspawn'
    ]
}, (chatmsg) => {
    if (!Server.player.find(chatmsg.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    if (!Server.entity.getScore(`cl${CMDTname}`, '[type=rot:cl]', { minimum: 0, maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=!v] {"rawtext":[{"text":"${Lang.CMDnotOna1}${CMDTname}${Lang.CMDnotOna2}"}]}`, `tellraw @a[name="${chatmsg.sender.nameTag}",tag=v] {"rawtext":[{"text":"${Lang.CMDnotOnb1}${CMDTname}${Lang.CMDnotOnb2}${CMDTname}${Lang.CMDnotOnb3}"}]}`]);
    if (Server.player.getScore('clcmd', `${chatmsg.sender.nameTag}`, { minimum: 1, maximum: 3 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `execute @a[name="${chatmsg.sender.nameTag}"] ~~~ tellraw @s {"rawtext":[{"text":"${Lang.antispam}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 0`, `execute @e[type=rot:cl,scores={cl${CMDTname}=!2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}"] clcmdc 1`, `execute @e[type=rot:cl,scores={cl${CMDTname}=2}] ~~~ scoreboard players set @a[name="${chatmsg.sender.nameTag}",tag=t] clcmdc 1`]);
    if (!Server.player.getScore('clcmdc', `${chatmsg.sender.nameTag}`, { maximum: 0 }))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.noT}"}]}`]);
    Server.runCommands([`scoreboard players set @a[name="${chatmsg.sender.nameTag}",m=!c] clcmd 3`]);
    if (Server.player.findTag('last_hit_by_player', chatmsg.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${chatmsg.sender.nameTag}"]`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.anticlog}"}]}`]);
    if (Server.entity.getScore('clspawn', '[type=rot:cl]', { minimum: 0 }))
        return Server.runCommands([`playsound random.toast @a[name="${chatmsg.sender.nameTag}"] 1 0.5`, `tellraw @a[name="${chatmsg.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC}\u00a7\u0061 \u0053\u0065\u0074 \u0073\u0070\u0061\u0077\u006e \u0074\u006f\u00a7\u0036\u00a7\u006c ${Math.trunc(chatmsg.sender.location.x)}\u002c ${Math.trunc(chatmsg.sender.location.y)}\u002c ${Math.trunc(chatmsg.sender.location.z)}\u00a7\u0072\u00a7\u0061! \u0054\u0079\u0070\u0065 \u00a7\u0037!\u0073\u0070\u0061\u0077\u006e\u00a7\u0061 \u0069\u006e \u0063\u0068\u0061\u0074 \u0074\u006f \u0074\u0065\u006c\u0065\u0070\u006f\u0072\u0074 \u0074\u006f \u0069\u0074 \u0077\u0068\u0065\u006e\u0065\u0076\u0065\u0072 \u0079\u006f\u0075 \u0077\u0061\u006e\u0074\u002e"}]}`, `scoreboard players set @e[type=rot:cl] clsx ${Math.trunc(chatmsg.sender.location.x)}`, `scoreboard players set @e[type=rot:cl] clsy ${Math.trunc(chatmsg.sender.location.y)}`, `scoreboard players set @e[type=rot:cl] clsz ${Math.trunc(chatmsg.sender.location.z)}`]);
});
