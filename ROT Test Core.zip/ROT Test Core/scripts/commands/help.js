/*
ROT Developers and Contributors:
Moises (OWNER/CEO),
TRASH (DEVELOPER),
notbeer (Most of ROT's Structure code),
Nightwalker L.o.t.s (ROT Anti Cheat Dev),
UnknownCatastrophe (ROT Anti Cheat Dev),
VUnkownPersonV (ROT Anti Cheat Dev),
__________ ___________________
\______   \\_____  \__    ___/
 |       _/ /   |   \|    |
 |    |   \/    |    \    |
 |____|_  /\_______  /____|
        \/         \/
Do NOT steal, copy the code, or claim it as yours!
Please message moisesgamingtv9#8583 on Discord, or join the ROT discord: https://discord.com/invite/2ADBWfcC6S
You can also message one of our developers on Discord @TRASH#6969
Copyright 2021-2022!
Thank you!
*/
import { Server, Lang } from '../Minecraft.js';
const registerInformation = {
    cancelMessage: true,
    name: 'help',
    description: 'Get list of all the commands available or input an argument to get information about that specific command',
    usage: 'help [command name]',
    example: [
        'help',
        'help spawn',
        'help warps'
    ]
};
Server.command.register(registerInformation, (data, args) => {
    if (!Server.player.find(data.sender.nameTag))
        return null;
    if (!Server.player.findTag('rot', data.sender.nameTag))
        return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`, `tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.setupa}"}]}`]);
    var cmdList = Server.command.getAll();
    var args0_is_int = false;
    try {
        if (args[0])
            parseInt(args[0]);
        args0_is_int = true;
    }
    catch (e) {
        args0_is_int = false;
    }
    if (args0_is_int || !args[0]) {
        Server.runCommands([`playsound random.toast @a[name="${data.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"\u003c\u00a7\u006c\u0042\u006c\u0061\u006e\u006b\u00a7\u0072\u003e \u004a\u006f\u0069\u006e \u0074\u0068\u0065 \u0052\u004f\u0054 \u0044\u0069\u0073\u0063\u006f\u0072\u0064 \u0069\u0066 \u0079\u006f\u0075 \u006e\u0065\u0065\u0064 \u0061\u006e\u0079 \u006d\u006f\u0072\u0065 \u0068\u0065\u006c\u0070!\u00a7\u006c\u00a7\u0064 \u0064\u0069\u0073\u0063\u006f\u0072\u0064\u002e\u0067\u0067\u002f\u006a\u0034\u0039\u0045\u0041\u0034\u0042\u0037\u0039\u0071"}]}`]);
        var color_int = 0;
        var commands_list = cmdList;
        var n = 15;
        var help_page = args[0] ? parseInt(args[0]) : 1;
        var help_page_original = help_page;
        if (help_page != 0) {
            help_page = help_page - 1;
        }
        // @ts-ignore
        var result = new Array(Math.ceil(commands_list.length / n)).fill().map(_ => commands_list.splice(0, n));
        for (let i = 0; i < result[help_page].length; i++) {
            color_int++;
            if (color_int > 1) {
                color_int = 0;
            }
            var help = "";
            if (color_int == 0) {
                help += "§b§l";
            }
            if (color_int == 1) {
                help += "§c§l";
            }
            var cmdInfo2 = Server.command.getRegistration(result[help_page][i]);
            help += result[help_page][i];
            if (cmdInfo2.description)
                help += `§d - §a${cmdInfo2.description}\n`;
            Server.broadcast(`${help}`, `${data.sender.nameTag}`);
        }
        Server.broadcast(`§l§cHelp page:§r §a${help_page_original}§d/§b${result.length}`, `${data.sender.nameTag}`);
        Server.broadcast(`§bUse §c ${Server.CP}help §d<Page Number> §bTo see the next page`, `${data.sender.nameTag}`);
        return;
    }
    const cmdInfo = Server.command.getRegistration(args[0]);
    if (!cmdInfo)
        return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`, `tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cI couldn't find the command..."}]}`]);
    if (cmdInfo && cmdInfo.private)
        return Server.runCommands([`playsound random.glass @a[name="${data.sender.nameTag}"]`, `tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${Lang.MSC} §cI couldn't find the command..."}]}`]);
    let hI = `\n${Lang.MSC} §l§eCommand§b: §l§a${Server.command.prefix}§l§c${cmdInfo.name}§r\n`;
    if (cmdInfo.aliases)
        hI += `§l§eAliases§b: §c${cmdInfo.aliases.join(`§a,\n§l${Server.command.prefix}§r§b`)}§r\n`;
    if (cmdInfo.description)
        hI += `§l§eDescription§b:§r§a ${cmdInfo.description}\n`;
    if (cmdInfo.usage)
        hI += `§l§eUsage§b: §a${Server.command.prefix}§r§b${cmdInfo.usage}\n`;
    if (cmdInfo.example)
        hI += `§l§eExamples§b:\n§a${Server.command.prefix}§r§b${cmdInfo.example.join(`§a,\n§l${Server.command.prefix}§r§b`)}`;
    return Server.runCommands([`playsound random.toast @a[name="${data.sender.nameTag}"] ~~~ 1 0.5`, `tellraw @a[name="${data.sender.nameTag}"] {"rawtext":[{"text":"${hI}"}]}`]);
});
